//console.log("Hello World")

let myFirstName = "Amir";
console.log("myFirstName")